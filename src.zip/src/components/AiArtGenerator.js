import React, { useState } from 'react';
import { generateImage } from '../services/aiArtService';

const AiArtGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImage, setGeneratedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await generateImage(prompt);
      setGeneratedImage(result.data[0].url); // 假设API返回的图片URL在这个位置
    } catch (err) {
      setError('生成图片时发生错误，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ai-art-generator">
      <h2>AI绘画生成器</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="请描述你想要生成的图片..."
          rows={4}
          className="prompt-input"
        />
        <button 
          type="submit" 
          disabled={loading || !prompt.trim()}
        >
          {loading ? '生成中...' : '生成图片'}
        </button>
      </form>

      {error && <div className="error-message">{error}</div>}
      
      {generatedImage && (
        <div className="generated-image">
          <img src={generatedImage} alt="AI生成的图片" />
        </div>
      )}
    </div>
  );
};

export default AiArtGenerator; 