import AiArtGenerator from './components/AiArtGenerator';
import './styles/AiArtGenerator.css';

function App() {
  return (
    <div className="App">
      <AiArtGenerator />
    </div>
  );
}

export default App; 