const API_URL = 'https://api.siliconflow.cn/v1/images/generations';
const API_KEY = 'sk-ttncbnpnvrqxmhiugxxucrlzrkhhpivxmdsrlrwbnmrtxwvg';

export const generateImage = async (prompt, options = {}) => {
  const defaultOptions = {
    model: "stabilityai/stable-diffusion-3-5-large",
    image_size: "1024x1024",
    batch_size: 1,
    seed: 4999999999,
    num_inference_steps: 20,
    guidance_scale: 7.5,
    prompt_enhancement: false
  };

  const requestOptions = {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      ...defaultOptions,
      ...options,
      prompt
    })
  };

  try {
    const response = await fetch(API_URL, requestOptions);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('生成图片时出错:', error);
    throw error;
  }
} 